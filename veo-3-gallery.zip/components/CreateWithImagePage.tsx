/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import React, {useState, useCallback, useRef} from 'react';
import {ArrowUpTrayIcon, XCircleIcon} from './icons';

interface CreateWithImagePageProps {
  onGenerate: (prompt: string, image: {data: string, mimeType: string}) => void;
  onCancel: () => void;
}

export const CreateWithImagePage: React.FC<CreateWithImagePageProps> = ({
  onGenerate,
  onCancel,
}) => {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<{file: File; dataUrl: string} | null>(
    null,
  );
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File | null) => {
    if (file) {
      if (file.size > 4 * 1024 * 1024) {
        setError('Image size should not exceed 4MB.');
        return;
      }
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file.');
        return;
      }
      setError(null);
      const reader = new FileReader();
      reader.onload = () => {
        setImage({file, dataUrl: reader.result as string});
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileSelect(e.target.files?.[0] ?? null);
  };
  
  const onDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  }, []);

  const onDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    handleFileSelect(e.dataTransfer.files?.[0] ?? null);
  }, []);

  const handleRemoveImage = () => {
    setImage(null);
    if(fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleGenerate = async () => {
    if (!image) {
      setError('Please upload an image.');
      return;
    }
    if (!prompt.trim()) {
      setError('Please enter a prompt.');
      return;
    }

    const base64Data = image.dataUrl.split(',')[1];
    onGenerate(prompt, {data: base64Data, mimeType: image.file.type});
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans flex flex-col items-center justify-center p-4 animate-fade-in">
      <div className="w-full max-w-2xl bg-gray-800 p-6 md:p-8 rounded-lg shadow-2xl">
        <header className="mb-6">
          <h1 className="text-2xl md:text-3xl font-bold text-white mb-1">
            Create Video from Image
          </h1>
        </header>

        <main className="flex flex-col gap-6">
          <div>
            <label
              htmlFor="image-upload"
              className="block text-sm font-medium text-gray-300 mb-2">
              Upload an Image
            </label>
            {image ? (
              <div className="relative group">
                <img
                  src={image.dataUrl}
                  alt="Preview"
                  className="w-full h-64 object-contain rounded-lg bg-gray-900"
                />
                <button
                  onClick={handleRemoveImage}
                  className="absolute top-2 right-2 p-1 bg-black/50 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity"
                  aria-label="Remove image">
                  <XCircleIcon className="w-6 h-6" />
                </button>
              </div>
            ) : (
              <div
                onDragOver={onDragOver}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-64 border-2 border-dashed border-gray-600 rounded-lg flex flex-col items-center justify-center text-gray-400 hover:bg-gray-700/50 hover:border-purple-500 transition-colors cursor-pointer"
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    fileInputRef.current?.click();
                  }
                }}
              >
                <ArrowUpTrayIcon className="w-12 h-12 mb-2" />
                <p>Drag & drop an image here</p>
                <p className="text-sm">or click to select a file</p>
                <input
                  type="file"
                  id="image-upload"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleImageChange}
                />
              </div>
            )}
          </div>
          <div>
            <label
              htmlFor="description"
              className="block text-sm font-medium text-gray-300 mb-2">
              Video text prompt
            </label>
            <textarea
              id="description"
              rows={5}
              className="w-full bg-gray-900 border border-gray-700 rounded-lg p-3 text-gray-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-shadow duration-200"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="e.g., A cinematic shot of a car driving on a rainy night"
              aria-label="Video text prompt"
            />
          </div>
          {error && <p className="text-red-400 text-sm">{error}</p>}
        </main>

        <footer className="flex justify-end gap-4 mt-8">
          <button
            onClick={onCancel}
            className="px-6 py-2 rounded-lg bg-gray-600 hover:bg-gray-700 text-white font-semibold transition-colors">
            Cancel
          </button>
          <button
            onClick={handleGenerate}
            className="px-6 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-semibold transition-colors">
            Generate video
          </button>
        </footer>
      </div>
    </div>
  );
};
